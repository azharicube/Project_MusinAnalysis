#!/bin/bash

batchid=`cat /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/logs/current-batch.txt`
LOGFILE=/home/acadgild/azhar/MusicDataAnalysis/Source_Codes/logs/log_batch_$batchid

echo "Placing data files from local to HDFS..." >> $LOGFILE

hadoop fs -rm -r /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/web/
hadoop fs -rm -r /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/formattedweb/
hadoop fs -rm -r /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/mob/

hadoop fs -mkdir -p /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/web/
hadoop fs -mkdir -p /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/mob/

hadoop fs -put /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/data/web/* /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/web/
hadoop fs -put /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/data/mob/* /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/batch${batchid}/mob/

echo "Running pig script for data formatting..." >> $LOGFILE

pig -param batchid=$batchid /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/scripts/dataformatting.pig

echo "Running hive script for formatted data load..." >> $LOGFILE

hive -hiveconf batchid=$batchid -f /home/acadgild/azhar/MusicDataAnalysis/Source_Codes/scripts/formatted_hive_load.hql
